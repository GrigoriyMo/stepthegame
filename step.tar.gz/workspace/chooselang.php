<?php

?>
<html>
<head>
    
    <style>
        html{
            background:black;
        }
    </style>
    
<script>
//var userName = prompt("Please, enter Your name");
</script>
<title>Le pouvoir de Kenar</title>
<link rel="stylesheet" type="text/css" href="css/mysite.css">
<meta charset="UTF-8">
</head>

<body>





<div class="chooselanguage">
    <a href ="mainmenu.php"><div class = "fra"></div></a>
    <a href ="mainmenu.php"><div class = "rus"></div></a>
    <a href ="mainmenu.php"><div class = "eng"></div></a>
</div>





</div>
</body>

</html>



